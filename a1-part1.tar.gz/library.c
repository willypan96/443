#include "library.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timeb.h>


long get_time(){
	struct timeb t;
	ftime(&t);
	long now_in_ms = t.time * 1000 + t.millitm;
	return now_in_ms;
}

/**
 * populate a random array (which is already
 * allocated with enough memory to hold n bytes.
 */
void random_array(char *array, long bytes){
	int i = 0;
	//Assume each char is 1 byte
	while (i < bytes){
		array[i] = 'A' + (rand() % 26);
		i++;
	}
}

/**
 * file_ptr : the file pointer, ready to be read from.
 * hist: an array to hold 26 long integers.  hist[0] is the
 *       number of 'A', and hist[1] is the number of 'B', etc.
 * block_size: the buffer size to be used.
 * milliseconds: time it took to complete the file scan
 * total_bytes_read: the amount data in bytes read
 *
 * returns: -1 if there is an error.
 */
int get_histogram(FILE *file_ptr, long hist[], int block_size, long *milliseconds, long *total_bytes_read)
{
    if (file_ptr == NULL)
    {
        return -1;
    }
    char *buffer;
    /* Initial memory allocation */
    buffer = (char *)malloc(block_size);
    int counter = 0;
    int index;
    long cur_time, end_time;
    cur_time = get_time();
    while (counter < (*total_bytes_read / (long)block_size))
    {
        fread(buffer, block_size, 1, file_ptr);
        for (index = 0; index < block_size; index++)
        {
            hist[buffer[index] - 'A'] += 1;
        }
        counter++;
    }
    fclose(file_ptr);
    end_time = get_time();

    *milliseconds = end_time - cur_time;
    return 0;
}