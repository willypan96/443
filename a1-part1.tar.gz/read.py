from subprocess import check_output

block_sizes = [1, 10, 100, 1000, 10000, 100000, 1000000, 1500000, 2000000, 2500000, 2800000, 3000000]
file = "output.txt"

print file
print "read rate,block size"
for block_size in block_sizes:
  out = check_output(["./get_histogram", file, str(block_size)])
  print str(out) + "," +str(block_size) 