#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/timeb.h>
#include "library.h"

int main(int argc, char **argv){
	
	long total_bytes, t_begin, t_end;
	int block_size, i = 0;
	char *buffer;
	FILE *fp;
	
	if(argc == 4){
		total_bytes = (long)(atoi(argv[2]));
		block_size = atoi(argv[3]);

		buffer = malloc(sizeof(char) * block_size);

		fp = fopen(argv[1], "w");
		if(fp == NULL)
		{
			return -1;
		}	

        t_begin = get_time();
		while (i < (total_bytes / block_size))
		{
			random_array(buffer, block_size);
			fwrite(buffer, block_size, 1, fp);
			fflush(fp);
			i++;
		}
		if (total_bytes % block_size > 0)
		{
			random_array(buffer, total_bytes % block_size);
			fwrite(buffer, block_size, 1, fp);
			fflush(fp);
		}
		t_end= get_time();
		
		fclose(fp);
		printf("Time: %ld ms, File: %s, Size:%lu, Block Size: %d, Avg Rate:%f bytes/s\n\n",t_end - t_begin, argv[1],total_bytes, block_size, (double)total_bytes/(t_end - t_begin)* 1000);
		return 0;
	}
	
	else{
		printf("\nUsage: .\\create_random_file <filename> <total bytes> <block size>\nProgram terminated\n\n");
		return -1;

	}
}
